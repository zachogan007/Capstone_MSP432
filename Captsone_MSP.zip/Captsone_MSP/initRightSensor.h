/*
 * initRightSensor.h
 *
 *  Created on: Oct 19, 2022
 *      Author: Zac Hogan
 */

#ifndef INITRIGHTSENSOR_H_
#define INITRIGHTSENSOR_H_

/*!
 * @brief Initialize input for Right piezo electric sensor using GPIO library.
 * @param[in] void   Only performs initializing of input pin 1.5. This also initializes Red LED as output for testing.
 * @return NA
 */
void
InitializeRightSensorPortPin(void);




#endif /* INITRIGHTSENSOR_H_ */
