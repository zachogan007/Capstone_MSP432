/*
 * servo.h
 *
 *  Created on: Oct 30, 2022
 *      Author: Zac Hogan
 */

#ifndef SERVO_H_
#define SERVO_H_




/**
 * @file      Motor.h
 * @brief     Provides low-level functions for interfacing with the motors
 ******************************************************************************/

#include <stdint.h>



/*
 * Motor connections on the robot:
 *   Left Motor:                Right Motor:
 *    - Direction: P5.4         - Direction: P5.5
 *    - PWM:       P2.7         - PWM        P2.6
 *    - Enable:    P3.7         - Enable     P3.6
 */

/**
 * Initialize GPIO pins and PWM for motor output
 * @param none
 * @return none
 */
void Servo_Init(void);

/**
 * Move robot forward by running both motors in the forward direction
 * @param leftDuty: the forward duty cycle of the left motor (P2.7)
 * @param rightDuty: the forward duty cycle of the right motor (P2.6)
 * @return none
 */
void Servo_Unlock(void);

/**
 * Move robot backwards by running both motors in the reverse direction
 * @param leftDuty: the backwards duty cycle of the left motor (P2.7)
 * @param rightDuty: the backwards duty cycle of the right motor (P2.6)
 * @return none
 */
void Servo_Lock(void);


/**
 * Stops the robot and puts the motors into sleep mode by setting the enable pins (P3.6 and P3.7)
 * @param none
 * @return none
 */
void Servo_Stop(void);


#endif






