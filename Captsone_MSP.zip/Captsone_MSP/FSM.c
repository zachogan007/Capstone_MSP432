/*
 * FSM.c
 *
 *  Created on: Oct 22, 2022
 *      Author: Zac Hogan
 */

#include "msp.h"
#include <stdint.h>
#include <stdbool.h>
#include <stdlib.h>
#include <stdio.h>
#include "../Capstone/TI_Files/Clock.h"
#include "../DriverLibrary/driverLib.h"
#include "deepSleep.h"
#include "initRightSensor.h"
#include "initLeftSensor.h"
#include "../Capstone/TI_Files/Timer_a.h"
#include "FSM.h"
#include "compare.h"
#include "TI_Files/Switch.h"
#include "PWM.h"
#include "servo.h"



#define MAX_KNOCKS 15



//These are global variables currently used to and ensure proper transitions of FSM state.
//These should be added to a struct for next deliverable. 11/16.
//
static int g_knock_key_array[MAX_KNOCKS];
static int g_input_array[MAX_KNOCKS];
int *g_store_array;
static bool g_done_listening = false;
static bool g_done_recording = false;
static bool g_done_comparing = false;
static bool g_done_unlocking = false;
static bool g_done_locking   = false;
bool g_interrupt_lock = false;
static bool g_match = false;
bool g_knock_lock_received = false;
static bool g_read_lock = false;
static bool g_listen_lock = false;
bool g_first_read = false;
bool g_first_listen = false;
char* g_string = "hello";
uint32_t g_fsm_time = 0;
uint32_t g_prev_read = 0;
uint32_t g_prev_read_listen = 0;
 bool g_first_step = true;
static bool g_done_storing = false;
static bool g_done_resetting = false;
uint32_t g_knock_time = 0;
static bool g_unlock_latch = false;
static bool g_lock_latch = false;
static bool g_deep_sleep = true;
int g_reset_val = 0;
static int i = 0;
int g_key_array_size = 0;
int g_input_arraySize = 0;

int g_first = 0;
int g_second = 0;
int g_locked = 0;

/*!
 * @brief InitializeFSM will initialize relevant LED portpins for testing and it will initialize to the Idle State.
 * @param[in] FSMType *FSM, this will carry in an address to the FSM struct that maintains input values and state values.
 * @return void
 */
void InitializeFSM(FSMType *FSM)
{
    FSM->CurrentState = idle;

    //Setting red LED as output.
    SET_LED2_B_AS_AN_OUTPUT;
    //Setting blue LED as output.
    SET_LED2_R_AS_AN_OUTPUT;

    SET_LED2_G_AS_AN_OUTPUT;


    TURN_OFF_LED2_RED;
    TURN_OFF_LED2_GREEN;
    TURN_OFF_LED2_BLUE;


    g_done_recording = false;
    g_done_listening = false;
    g_deep_sleep = true;

    Servo_Init();

    //GPIO_setOutputLowOnPin(GPIO_PORT_P5, GPIO_PIN6); //LEFT ENABLE enabled =
    i = 0;
    TURN_OFF_LED2_GREEN;

}


/*!
 * @brief NextStateFunction will return the next state of the FSM based on current input conditions.
 * @param[in] FSMType *FSM, this will carry in an address to the FSM struct that maintains input values and state values.
 * @return FSMState, This will update the FSMType struct with the next state to be accessed from main.c.
 */
FSMState NextStateFunction(FSMType *FSM)
{


        FSMState NextState = FSM->CurrentState;

        switch(FSM->CurrentState){

                    //Remain in idle state until an interrupt is triggered from the piezo sensor.
                    case idle:
                    g_string = "idle";

                    if(FSM->CurrentInputS1 == Active){
                        NextState = reset;

                    }

                    //If start is 1, then a key sequence arrays needs to be made.
                    //
                    else if(!g_done_recording && (FSM->leftSensorInput < 1 || FSM -> rightSensorInput < 1))
                    {
                        //__low_power_mode_off_on_exit(); UNCOMMENT
                        g_read_lock = true;
                        NextState = wakeUpAndRecord;
                    }

                    //If start is 0, then user input is stored in a temporary user array.
                    else if(g_done_recording && (FSM->leftSensorInput < 1 || FSM -> rightSensorInput < 1))
                    {
                        //__low_power_mode_off_on_exit(); UNCOMMENT
                        g_listen_lock = true;
                        NextState = listenState;
                    }

                    else{


                        NextState = NextState;
                      //  __WFI(); UNCOMMENT
                    }



                    break;



                    //Record for the duration of the record state, and then move to the listen state when recording is complete.
                    //
                    case  wakeUpAndRecord:


                    g_string = "wakeUP";
                    if(!g_done_recording){
                        NextState = NextState;

                    }

                    else if(g_done_recording){


                        NextState = storeState;

                    }

                    break;



                    case storeState:
                        g_string = "store";
                        if(!g_done_storing){

                            NextState = NextState;

                        }

                        else if(g_done_storing){

                            NextState = idle;
                        }


                     break;



                    //Listen for user input for the allowable number of knocks and within time constraints.
                    //Move to the compare state when the user array has been obtained.
                    //

                    case listenState:
                      g_string = "listen";
                    //g_done_recording = false;
                      if(FSM->CurrentInputS1 == Active)
                          {

                              NextState = reset;
                          }

                      else if(!g_done_listening)
                    {

                        NextState = listenState;
                    }

                    else if(g_done_listening)
                    {
                        NextState = compare;

                    }



                    break;



                    //Compare the key sequence array and the user input array and then make a decision to return to listen
                    //or unlock.
                    //
                    case compare:

                     g_string = "compare";

                    if(g_match && g_done_comparing)
                    {
                        g_unlock_latch = true;
                        NextState = unlock;
                    }

                    else if(!g_match && g_done_comparing )
                    {
                        NextState = idle;
                    }


                    break;


                    //Unlock the sensoro if it passes.
                    case unlock:

                    g_string = "UNLOCK";
                    if((!g_done_unlocking || g_done_unlocking) && !(FSM->leftSensorInput < 1 || FSM -> rightSensorInput < 1))
                    {
                        NextState = NextState;
                    }


                    else if(g_done_unlocking && (FSM->leftSensorInput < 1 || FSM -> rightSensorInput < 1))
                    {
                        g_done_unlocking = false;
                        g_unlock_latch = false;
                        g_lock_latch = true;
                        NextState = lockKnock;
                    }



                    break;



                    //Wait for a lock knock to lock again.
                    case lockKnock:

                        g_string = "LOCK KNOCK";

                    if(g_done_locking)
                    {

                        g_done_locking = false;
                        NextState = idle;
                    }

                    else if(!g_done_locking)
                    {
                        NextState = NextState;
                    }

                    break;


                    //Reset if reset value is carried in.
                    case reset:

                     g_string = "RESET";

                     if(g_done_resetting){
                     NextState = idle;
                     g_done_recording = false;
                     g_done_listening = false;
                     g_done_resetting = false;
                     }

                     else if(!g_done_resetting){

                         NextState = NextState;
                     }


                    break;


        }

        return NextState;
}





/*!
 * @brief This function will access the given case of the FSM state and it will implement controls and outputs per state.
 * @param[in] FSMType *FSM, this will carry in an address to the FSM struct that maintains input values and state values.
 * @return void, this will only implement output controls and will not modify state directly.
 */
void OutputFunction(FSMType *FSM)
{

     switch (FSM->CurrentState)
     {

            case idle:


                TURN_ON_LED2_GREEN;

                /*
                   if(FSM->millisecondRead > 3000){
                       FSM -> timerReset = 1;
                       g_locked = 0;
                   }



                    if(g_first == 0 && !g_locked ){
                       Servo_Unlock();
                       g_first = 1;
                       g_locked = 1;
                      }
                   else if(g_first == 1 && !g_locked){
                       Servo_Lock();
                       g_locked = 1;
                       g_first = 0;
                   }


                   if(FSM->millisecondRead > 3000 && FSM->millisecondRead < 750 && g_first == 1){
                                    Servo_Stop();
                                  }

                   if(FSM->millisecondRead > 3000 && FSM->millisecondRead < 750 && g_first == 0){
                                                       Servo_Stop();

                                                     }
                                                     */

                 if(g_deep_sleep)
                   {
                     g_deep_sleep = false;
                    // deepSleepMode(); //UNCOMMENT
                     g_string = "g_deep_sleep";
                   }







                 //PORT4_IRQHandler();
                 //TURN_ON_LED2_GREEN;
                 //GPIO_setOutputHighOnPin(GPIO_PORT_P2, GPIO_PIN1);
                  //GPIO_setOutputHighOnPin(GPIO_PORT_P2, GPIO_PIN2);
                 TURN_OFF_LED2_GREEN;

            break;


            case wakeUpAndRecord:

                TURN_ON_LED2_BLUE;
                TURN_OFF_LED2_BLUE;
                     //TURN_OFF_LED2_GREEN;
                     //GPIO_setOutputLowOnPin(GPIO_PORT_P2, GPIO_PIN1);
                  //If a knock is detected, store 0th element at 0 ms.
                  //Each element of the array is a timestamp
                  //First the timer is initiated to 0 and then a value is turned on.
               if(g_read_lock == true){
                      //FSM -> timerReset = 1;
                   //TURN_OFF_LED2_GREEN;
                      i=0;
                      g_read_lock = false;
                      g_prev_read = 0;
                      g_done_recording = false;
                      g_read_lock = false;
                      g_first_step = true;
                      FSM -> timerReset = 1;
                  }

               else
               {

                     if(i == 0  && (FSM->leftSensorInput < 1)){

                         if(g_first_step == true){
                         FSM -> timerReset = 1;
                         g_first_step = false;
                         //}
                        // else{
                         g_knock_key_array[i] = FSM->millisecondRead;
                         g_prev_read = FSM->millisecondRead;

                         ++i;

                         }

                     }

                     else if(i == 0  && (FSM -> rightSensorInput < 1)){
                       if(g_first_step == true){
                       FSM -> timerReset = 1;
                        g_first_step = false;
                       //}
                       //else{
                        g_input_array[i] = -1*(FSM->millisecondRead);
                        g_prev_read_listen = FSM->millisecondRead;
                        ++i;

                     }
                   }

                     //GPIO_setOutputLowOnPin(GPIO_PORT_P2, GPIO_PIN1);
                     else if((FSM->leftSensorInput < 1) && i < MAX_KNOCKS && i>0){
                         //GPIO_setOutputHighOnPin(GPIO_PORT_P2, GPIO_PIN1);
                         if(g_prev_read+100<FSM->millisecondRead)
                         {
                         g_knock_key_array[i] = (FSM->millisecondRead);
                         g_prev_read = FSM->millisecondRead;
                         ++i;
                         }

                     }


                     else if(FSM -> rightSensorInput < 1 && i < MAX_KNOCKS && i > 0)
                     {
                         //GPIO_setOutputHighOnPin(GPIO_PORT_P2, GPIO_PIN2);
                         if(abs(g_prev_read)+100 < FSM->millisecondRead)
                         {
                          g_knock_key_array[i] = (FSM->millisecondRead)*-1;
                         g_prev_read = FSM->millisecondRead;
                        ++i;
                         }
                     }


                     else if(i == MAX_KNOCKS || FSM->millisecondRead > 5000)
                     {
                      g_prev_read_listen = FSM->millisecondRead;
                      g_done_recording = true;

                     }

                     //GPIO_setOutputLowOnPin(GPIO_PORT_P2, GPIO_PIN2);

                   }

                 break;



           case listenState:



               TURN_ON_LED2_RED;
               TURN_OFF_LED2_RED;
                 //TURN_OFF_LED2_GREEN;

                 //GPIO_setOutputLowOnPin(GPIO_PORT_P2, GPIO_PIN1);

                 if(g_listen_lock == true)
                 {
                     i=0;
                     g_prev_read_listen = 0;
                     g_listen_lock = false;
                     g_done_recording = true;
                     g_done_listening = false;
                     g_first_step = true;
                     FSM -> timerReset = 1;
                 }
                 else{
                 //If a knock is detected, store 0th element at 0 ms.
                 //Each element of the array is a timestamp
                 //First the timer is initiated to 0 and then a value is turned on.
                 //
                     if(i == 0  && (FSM->leftSensorInput < 1)){
                         if(g_first_step == true){
                         FSM -> timerReset = 1;
                          g_first_step = false;
                         //}
                         //else{
                          g_input_array[i] = FSM->millisecondRead;
                          g_prev_read_listen = FSM->millisecondRead;
                          ++i;
                         }

                      }

                      else if(i == 0  && (FSM -> rightSensorInput < 1)){
                          if(g_first_step == true){
                          FSM -> timerReset = 1;
                           g_first_step = false;
                          //}
                          //else{
                           g_input_array[i] = -1*(FSM->millisecondRead);
                           g_prev_read_listen = FSM->millisecondRead;
                           ++i;
                          }
                      }

                      //GPIO_setOutputLowOnPin(GPIO_PORT_P2, GPIO_PIN1);
                      else if(FSM->leftSensorInput < 1 && i < MAX_KNOCKS && i > 0)
                      {
                          //GPIO_setOutputHighOnPin(GPIO_PORT_P2, GPIO_PIN1);
                          if(g_prev_read_listen+100 < FSM->millisecondRead)
                          {
                          g_input_array[i] = (FSM->millisecondRead);
                          g_prev_read_listen = FSM->millisecondRead;
                          ++i;
                          }

                      }


                      else if(FSM -> rightSensorInput < 1 && i < MAX_KNOCKS && i > 0)
                      {
                         // GPIO_setOutputHighOnPin(GPIO_PORT_P2, GPIO_PIN2);
                          if(abs(g_prev_read_listen)+100 < FSM->millisecondRead)
                          {
                           g_input_array[i] = (FSM->millisecondRead)*-1;
                          g_prev_read_listen = FSM->millisecondRead;
                         ++i;
                          }
                      }

                    //  GPIO_setOutputLowOnPin(GPIO_PORT_P2, GPIO_PIN2);


                      else if((i == MAX_KNOCKS || FSM->millisecondRead > (abs(g_store_array[g_key_array_size-1])+2000)) && g_first_step == false)
                      {
                        g_prev_read_listen = FSM->millisecondRead;
                        g_done_listening = true;
                      }
                  }




                 break;


            case storeState:
                g_key_array_size = 0;
                for(i = 0; i < MAX_KNOCKS; ++i){
                    if(abs(g_knock_key_array[i]) > 0){
                        ++g_key_array_size;
                    }
                }
                ++g_key_array_size;
                g_store_array = malloc(g_key_array_size*sizeof(int));
                for(i = 0; i < g_key_array_size; ++i){
                    g_store_array[i] = g_knock_key_array[i];
                }



                g_done_storing = true;

                break;




             case compare:


                 g_input_arraySize = 0;
                 g_done_comparing =false;
                 //TURN_OFF_LED2_GREEN;
                 //GPIO_setOutputLowOnPin(GPIO_PORT_P2, GPIO_PIN0);
                 //GPIO_setOutputLowOnPin(GPIO_PORT_P2, GPIO_PIN1);
                 //GPIO_setOutputLowOnPin(GPIO_PORT_P2, GPIO_PIN2);
                 for(i = 0; i < MAX_KNOCKS; ++i){
                     if(g_input_array[i] > 0 || g_input_array[i] < 0 ){
                       ++g_input_arraySize;
                     }
                 }
                 ++g_input_arraySize;
                 g_match =  sequenceCompare(g_store_array, g_input_array, g_key_array_size, g_input_arraySize);

                 if(g_match){
                    // TURN_ON_LED2_GREEN;
                     for(i = 0; i < MAX_KNOCKS; ++i){
                         g_input_array[i] = 0;
                         GPIO_setOutputHighOnPin(GPIO_PORT_P2, GPIO_PIN0);
                     }
                 }
                 if(!g_match){
                     for(i = 0; i < MAX_KNOCKS; ++i){
                         g_input_array[i] = 0;
                         GPIO_setOutputHighOnPin(GPIO_PORT_P2, GPIO_PIN0);
                     }

                 }

                 g_done_comparing = true;

                 break;


             case unlock:

                 TURN_ON_LED2_GREEN;
                 TURN_ON_LED2_RED;
                  TURN_OFF_LED2_RED;
                  TURN_OFF_LED2_GREEN;


                 if(g_unlock_latch){
                 FSM -> timerReset = 1;
                 Servo_Unlock();
                 g_unlock_latch = false;
                 g_done_unlocking = false;
                 GPIO_setOutputHighOnPin(GPIO_PORT_P4, GPIO_PIN5);
                 }


                 else if(FSM->millisecondRead > 500 && FSM->millisecondRead < 1000 && !g_done_unlocking){
                 Servo_Stop();
                 GPIO_setOutputHighOnPin(GPIO_PORT_P4, GPIO_PIN5);
                 //g_done_unlocking = true;
                 }



                 //port pin P4.5
                 else if(FSM->millisecondRead > 1000){
                 //GPIO_setOutputLowOnPin(GPIO_PORT_P4, GPIO_PIN5);
                 g_done_unlocking = true;
                 }

                 //else{}


                 break;



             case lockKnock:

                 TURN_ON_LED2_BLUE;
                 TURN_ON_LED2_RED;
                 TURN_OFF_LED2_BLUE;
                 TURN_OFF_LED2_RED;



                 if(g_lock_latch){
                 FSM -> timerReset = 1;
                 Servo_Lock();
                 g_lock_latch = false;
                 g_done_unlocking = false;
                 g_done_locking = false;
                 }


                 else if(FSM->millisecondRead > 500 && FSM->millisecondRead < 1000 && !g_done_locking){
                 Servo_Stop();
                 //g_done_unlocking = true;
                 }


                 //port pin P4.5
                 else if(FSM->millisecondRead > 1000){
                 //GPIO_setOutputHighOnPin(GPIO_PORT_P4, GPIO_PIN5);
                     //TURN_OFF_LED2_BLUE;
                     //TURN_OFF_LED2_GREEN;
                   //  TURN_OFF_LED2_RED;
                 g_done_locking = true;
                 GPIO_setOutputLowOnPin(GPIO_PORT_P4, GPIO_PIN5);
                 }

                 //else{}

                break;

//Case reset is responsible for resetting conditional variables that would be necessary for the logic and flow to return to start state conditions.
//

             case reset:

                 for(i = 0; i < MAX_KNOCKS; ++i){
                     g_knock_key_array[i] = 0;
                     g_input_array[i] = 0;
                 }

                 g_store_array = NULL;
                 g_done_recording = false;
                 g_done_listening = false;
                 g_done_resetting = true;
                 g_read_lock = true;
                 g_listen_lock = true;
                 g_prev_read_listen = 0;
                 g_prev_read = 0;
                 FSM -> timerReset = 1;
                 g_key_array_size = 0;
                 g_input_arraySize = 0;
                 i = 0;


             break;
     }
}
