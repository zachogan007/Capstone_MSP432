/*
 * initRightSensor.c
 *
 *  Created on: Oct 19, 2022
 *      Author: Zac Hogan
 */

#include "TI_Files/PortPins.h"
#include "msp.h"
#include "TI_Files/PushButton.h"
//#include "../Capstone/TI_Files/LED.h"



/*!
 * @brief Initialize input for Right piezo electric sensor using GPIO library.
 * @param[in] void   Only performs initializing of input pin 1.5. This also initializes Red LED as output for testing.
 * @return NA
 */
void
InitializeRightSensorPortPin(void)
{


    //Initialize Input Pin 1.5
    GPIO_setAsPeripheralModuleFunctionInputPin(GPIO_PORT_P4, GPIO_PIN2, //initialize port pin for right piezo sensor reads.
    GPIO_PRIMARY_MODULE_FUNCTION);
}
