/*
 * servo.c
 *
 *  Created on: Oct 30, 2022
 *      Author: Zac Hogan
 */

#include "TI_Files/PortPins.h"
#include "msp.h"
#include "TI_Files/PushButton.h"
#include "PWM.h"
//#include "../Capstone/TI_Files/LED.h"




void Servo_Init(void){

//setting initial period to 100
   // GPIO_setAsOutputPin(GPIO_PORT_P5, GPIO_PIN6); //LEFT ENABLE
    PWM_Init(20000, 0);

    //GPIO_setOutputHighOnPin(GPIO_PORT_P5, GPIO_PIN6); //LEFT ENABLE enabled =
    //GPIO_setOutputLowOnPin(GPIO_PORT_P5, GPIO_PIN6); //LEFT ENABLE enabled =
    //GPIO_setOutputHighOnPin(GPIO_PORT_P5, GPIO_PIN6); //LEFT ENABLE enabled = 0



    //direction and enable
    //motor enable
    //GPIO_setAsOutput...
    //set enable pins to 0 OFF, 1 ON
    //set direction to low ->forward, 1->backwards
    //set as low

}


// Drive both motors forward at the given duty cycles
void Servo_Unlock(void){

     // GPIO_setOutputLowOnPin(GPIO_PORT_P5, GPIO_PIN6); //LEFT ENABLE enabled = 0
     // GPIO_setOutputHighOnPin(GPIO_PORT_P5, GPIO_PIN6); //LEFT DIRECTION MOTOR = forward
      PWM_Duty_Servo(10); //duty cycle power called from PWM for observable power given


}


// Drive both motors backwards at the given duty cycles
void Servo_Lock(void){

    //GPIO_setOutputLowOnPin(GPIO_PORT_P5, GPIO_PIN6); //LEFT DIRECTION MOTOR = backward

    PWM_Duty_Servo(12000);
}


// Drive the right motor forwards and the left motor backwards at the given duty cycles
void Servo_Stop(void){

    PWM_Duty_Servo(0);
   // GPIO_setOutputHighOnPin(GPIO_PORT_P5, GPIO_PIN6); //LEFT DIRECTION MOTOR = backward

}

