/*
Zachary Hogan (zh6nj)
FSM:SPI & LED Display
4/17/2021
Collaborations:
TA Office Hours
 */


/* DriverLib Includes */
#include "FSMTimerA1.h"
#include "driverlib.h"

/* Standard Includes */
#include <stdint.h>
#include <stdbool.h>

/* Project Includes */

// Pointer to user function that gets called on timer interrupt

//void declaration of TimerA1Task pointer
void (*TimerA1Task)(void);

// creating Timer_A_UpModeConfig struct with default period of zero
Timer_A_UpModeConfig timeStruct = {

     TIMER_A_CLOCKSOURCE_SMCLK,
     TIMER_A_CLOCKSOURCE_DIVIDER_24,
     0,
     TIMER_A_TAIE_INTERRUPT_DISABLE,
     TIMER_A_CCIE_CCR0_INTERRUPT_ENABLE,
     TIMER_A_DO_CLEAR,
     };



// Initializes Timer A1 in up mode and triggers a periodic interrupt at a desired frequency
void TimerA1_Init(void(*task)(void), uint16_t period){
  //carrying in value
  TimerA1Task = task;//user-defined function
  //setting timeStruct period to period passed in
  timeStruct.timerPeriod = period;
  //configuring to count in up mode
  Timer_A_configureUpMode(TIMER_A1_BASE, &timeStruct);
  //enable interrupt
  Interrupt_enableInterrupt(INT_TA1_0);
//starting counter from in up mode
  Timer_A_startCounter(TIMER_A1_BASE, TIMER_A_UP_MODE);
}




// stops Timer A1
void TimerA1_Stop(void){

//pointer to TimerA1  to Control register
//Hex representation to set bits 4 and 5 to 0 = ~0x0030
// bit masking ~0000 0000 0011 0000
// 1111 1111 1100 1111 4th and 5th bits set to 0 = 00 = STOP

TIMER_A1->CTL &= ~0x0030;
}

// ISR function for Timer A1 periodic interrupt
void TA1_0_IRQHandler(void){

//clearing interrupt flag for capture compare register

Timer_A_clearCaptureCompareInterrupt(TIMER_A1_BASE, TIMER_A_CAPTURECOMPARE_REGISTER_0);
//function pointer to user-defined task data
(*TimerA1Task)();

}
