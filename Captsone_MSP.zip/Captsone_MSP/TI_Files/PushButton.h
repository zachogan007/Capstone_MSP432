#ifndef PUSHBUTTON_H
#define PUSHBUTTON_H

#include "driverlib.h"
#include "PortPins.h"

// Prototypes
void InitializePushButtonPortPins(void);

#endif
