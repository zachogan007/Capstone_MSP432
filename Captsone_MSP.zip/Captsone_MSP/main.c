#include "msp.h"
#include <stdint.h>
#include <stdbool.h>
#include <stdio.h>
#include "../Capstone/TI_Files/Clock.h"
#include "../DriverLibrary/driverLib.h"
#include "deepSleep.h"
#include "initRightSensor.h"
#include "initLeftSensor.h"
#include "TI_Files/Timer_a.h"
#include "FSM.h"
#include "TI_Files/FSMTimerA1.h"
#include "TI_Files/UART0.h"
#include "TI_Files/Switch.h"
#include "servo.h"
#include "TI_Files/PortPins.h"
#include "TI_Files/PushButton.h"
#include "PWM.h"
#include "servo.h"
#include "ADCBatteryMonitor.h"




#define BATTERY_MONITOR_CONTROL_OUTPUT_PORT P3
#define BATTERY_MONITOR_CONTROL_OUTPUT_PIN_6 6
#define SET_BIT (0x01 << BATTERY_MONITOR_CONTROL_OUTPUT_PIN_6)
#define SET_P3_6_AS_BATERY_MONITOR_CONTROL_OUTPUT BATTERY_MONITOR_CONTROL_OUTPUT_PORT -> DIR |= SET_BIT
#define SET_BATTERY_MONITOR_CONTROL_OUTPUT_HIGH BATTERY_MONITOR_CONTROL_OUTPUT_PORT-> OUT = 1


#define PUSHBUTTON_S1_PIN                       1
#define PUSHBUTTON_S1_BIT                       (0x01 << PUSHBUTTON_S1_PIN)
#define PUSHBUTTON_S1_PORT                      P1
#define SET_PUSHBUTTON_S1_TO_AN_INPUT           PUSHBUTTON_S1_PORT->DIR &= ~PUSHBUTTON_S1_BIT
#define ENABLE_PULL_UP_PULL_DOWN_RESISTORS_S1   PUSHBUTTON_S1_PORT->REN |= PUSHBUTTON_S1_BIT
#define SELECT_PULL_UP_RESISTORS_S1             PUSHBUTTON_S1_PORT->OUT |= PUSHBUTTON_S1_BIT




//The following global variables will be added to the FSM struct after testing.
//Initialize sensor reading from right piezoelectric sensor to 0.
//
uint8_t input_right_read = 0;

//Initialize sensor reading from left piezoelectric sensor to 0.
//
uint8_t input_left_read = 0;

//Track which interrupt we are on cycling on.
//
uint8_t interruptNum;

//Initialize the current status of milliseconds to be passed to FSM.
//
uint32_t milliseconds = 0;

//FSMType struct linked to FSM.h and will be updated in main
//
FSMType knockFSM;


FSMState NextStateFunction(FSMType *FSM);


uint32_t CurrentSensorInput = 0;


static volatile float ADCconvert = 0;

/*!
 * @brief readSensorsTask will perform the operations of switching the inputs on a timer interrupt and it will track time in milliseconds.
 * @param[in] void   This method till update the global variable interruptNum to switch input reads and wil update time.
 * @return void
 */
void readSensorsTask(void)
{
   interruptNum++;

   if(interruptNum == 1)
   {
       input_right_read = GPIO_getInputPinValue(GPIO_PORT_P4, GPIO_PIN2); //Read the value from P4.2.
   }

   if(interruptNum == 2)
   {
       input_left_read = GPIO_getInputPinValue(GPIO_PORT_P4, GPIO_PIN0); //Read the value from P4.0.
   }

    if(interruptNum == 5)
    {
        interruptNum = 0;
    }

    ++milliseconds;
    knockFSM.millisecondRead = milliseconds;
}



/*!
 * @brief Main will call initialization functions and it will update and pass FSM struct values.
 * @param[in] void  No arguments are taken.
 * @return 0, this statement should never be reached as main will forever be stuck in its FSM configuration.
 */
int
main(void){
    //Stop the watchdog timer.
    //
    GPIO_setAsOutputPin(GPIO_PORT_P4, GPIO_PIN5);

	WDT_A->CTL = WDT_A_CTL_PW | WDT_A_CTL_HOLD;

	//This should call on the SMCLK frequency = 24MHz/24 Divider = 1MHz=> 1MHz/1000 = 1khZ = 1ms interrupt.
	//
    TimerA1_Init((&readSensorsTask), 500);

    //48MHz is the full MSP432 clock frequency
    //
	Clock_Init48MHz();

	//Initialize port pin to read from the left piezoelectric sensor.
	//
    InitializeLeftSensorPortPin();

    //Initialize port pin to read from the right piezoelectric sensor.
    //
    InitializeRightSensorPortPin();

    //Initializing P1.1 push button pin in order to manually set up a reset.
    //
    SwitchDefine PushButtonS1;

    //Calling on macros declared at the top of the program in order to set up the S1.1 switch for reset.
    //
    ENABLE_PULL_UP_PULL_DOWN_RESISTORS_S1;
    ENABLE_PULL_UP_PULL_DOWN_RESISTORS_S2;
    SELECT_PULL_UP_RESISTORS_S1;
    SELECT_PULL_UP_RESISTORS_S2;
    SET_PUSHBUTTON_S1_TO_AN_INPUT;
    SET_PUSHBUTTON_S2_TO_AN_INPUT;


    //Initialize Switch for reset with two potential states: Active and Inactive.
    //
    InitializeSwitch(&PushButtonS1, (uint8_t *) &(PUSHBUTTON_S1_PORT->IN),
                              (uint8_t) PUSHBUTTON_S1_BIT, Active, Inactive);


    // Call ADC_BatteryMonitor function in order to initialize ADC14 capture of battery levels. MIN = 0V. MAX 3.3V
    //
    ADC_BatteryMonitor();


    //For testing purposes, the battery monitor is included here and is set to high.
    //
    SET_P3_6_AS_BATERY_MONITOR_CONTROL_OUTPUT;
    SET_BATTERY_MONITOR_CONTROL_OUTPUT_HIGH;
    //GPIO_setOutputHighOnPin(GPIO_PORT_P4, GPIO_PIN5);



    //Initialize the original values of the FSM and start the IDLE state.
    //
    InitializeFSM(&knockFSM);

                    while(1)
                    {
                        //Continuously update the FSM current state with what is evaluated in the FSM NextState Function.
                        //
                        knockFSM.CurrentState = NextStateFunction(&knockFSM);

                        //Update the left sensor value with the input read from the left sensor input.
                        //
                        knockFSM.leftSensorInput = input_left_read;

                        //Update the right sensor value with what is read from the right piezo sensor.
                        //
                        knockFSM.rightSensorInput = input_right_read;

                        //Update the field of the S1 button switch with a status of active if pressed and inactive otherwise.
                        //
                        knockFSM.CurrentInputS1 = ReadSwitchStatus(&PushButtonS1);


                        //Update the FSM millisecond input based on current time handled by the task scheduler.
                        //Reset to time 0ms if timerReset is 1, or in other words if the push button has been pressed.
                        //
                        if(knockFSM.timerReset == 1)
                        {
                          milliseconds = 0;
                          knockFSM.millisecondRead = milliseconds;
                          knockFSM.timerReset = 0;
                        }
                        else
                        {
                         knockFSM.millisecondRead = milliseconds;
                        }

                        //Initialize FSM reset value to 0 for testing. CC3120 will pass this value into main.c later.
                        //
                        knockFSM.reset = 0;
                       // GPIO_setOutputHighOnPin(GPIO_PORT_P4, GPIO_PIN5);
                        //Retrieve the floating point value [0V, 3.3V] of from ADCBatteryMonitor.h.
                        ADCconvert = ADC14_IRQHandler();

                        //Wait and check for ADC interrupt on P3.6
                         // __WFI();

                        //Initialize FSM start value to 1 for testing.
                        //
                         knockFSM.start = 0;


                        //Continuously update the FSM output function based on FSM state.
                        //
                        OutputFunction(&knockFSM);

                    }
 }
