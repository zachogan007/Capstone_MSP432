/*
 * compare.c
 *
 *  Created on: Oct 17, 2022
 *      Author: Zac Hogan
 */


#include <stdbool.h>
#include <stdint.h>


/*!
 * @brief Compare the knock sequence arrays to ensure they match.
 * @param[in] stored_array  A pointer to the array of the sequence key.
 * @param[in] input_array   A pointer to the array of user input knocks.
 * @param[in] stored_length The number of knocks in the sequence key.
 * @param[in] input_length  The number of knocks collected by user input.
 * @return True if the sequences match and false otherwise.
 */
bool
sequenceCompare(int *stored_array, int *input_array, int stored_length, int input_length)
{

    //The array elements are times where knocks took place (recorded in milliseconds). Two examples are:
    //int stored_array[] = {0, 124, 500, 711, 1200, 1300}
    //int input_array[]  = {0, 170, 505, 737, 1212, 1313}.
    //
    if(stored_length != input_length)
    {
        return false;
    }

    int i = 0;

    for(i = 0; i < stored_length; i++)
    {
        //Determine if each input knock matches within 50ms of the sequence knock.
        //
        if(abs(stored_array[i] - input_array[i]) > 500)
        {
            return false;
        }
    }

    return true;
}



