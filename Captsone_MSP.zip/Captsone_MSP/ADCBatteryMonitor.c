/*
 * ADCBatteryMonitor.c
 *
 *  Created on: Nov 6, 2022
 *      Author: Zac Hogan
 *
 */

#include "msp.h"
#include "ADCBatteryMonitor.h"
#include "TI_Files/driverlib.h"

uint32_t g_adc_read = 0;

float g_adc_convert = 0;

void ADC_BatteryMonitor(void){


    //g_adc_read = 0;

    MAP_FlashCtl_setWaitState(FLASH_BANK0, 1);
    MAP_FlashCtl_setWaitState(FLASH_BANK1, 1);

    MAP_FPU_enableModule();
    MAP_FPU_enableLazyStacking();


    MAP_PCM_setPowerState(PCM_AM_LDO_VCORE1);
    MAP_CS_setDCOCenteredFrequency(CS_DCO_FREQUENCY_48);

    MAP_ADC14_enableModule();

    MAP_GPIO_setAsPeripheralModuleFunctionInputPin(GPIO_PORT_P5, GPIO_PIN5, GPIO_TERTIARY_MODULE_FUNCTION);


    MAP_ADC14_initModule(ADC_CLOCKSOURCE_MCLK, ADC_PREDIVIDER_1, ADC_DIVIDER_4,0);

    MAP_ADC14_configureSingleSampleMode(ADC_MEM0, true);

    MAP_ADC14_configureConversionMemory(ADC_MEM0, ADC_VREFPOS_AVCC_VREFNEG_VSS, ADC_INPUT_A0, false);


    MAP_ADC14_enableConversion();

    MAP_ADC14_toggleConversionTrigger();

    MAP_ADC14_enableInterrupt(ADC_INT0);
    MAP_Interrupt_enableInterrupt(INT_ADC14);
    MAP_Interrupt_enableMaster();


//MAY NEED TO ADJUST THIS CODE.



}



float ADC14_IRQHandler(void){

    g_adc_read = MAP_ADC14_getResult(ADC_MEM0);

    g_adc_convert = (g_adc_read*3.3)/(16384);

    MAP_ADC14_toggleConversionTrigger();

    return g_adc_convert;
}



