/*
 * compare.h
 *
 *  Created on: Oct 17, 2022
 *      Author: Zac Hogan
 */

#include <stdbool.h>

#ifndef COMPARE_H_
#define COMPARE_H_



/*!
 * @brief Compare the knock sequence arrays to ensure they match.
 * @param[in] stored_array  A pointer to the array of the sequence key.
 * @param[in] input_array   A pointer to the array of user input knocks.
 * @param[in] stored_length The number of knocks in the sequence key.
 * @param[in] input_length  The number of knocks collected by user input.
 * @return True if the sequences match and false otherwise.
 */
bool
sequenceCompare(int *stored_array, int *input_array, int stored_length, int input_length);

#endif /* COMPARE_H_ */
