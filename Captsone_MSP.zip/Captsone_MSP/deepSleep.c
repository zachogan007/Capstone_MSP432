
#include "TI_Files/PortPins.h"
#include "msp.h"
#include "TI_Files/PushButton.h"

void deepSleepMode(void){
    // Hold the watchdog
    WDT_A->CTL = WDT_A_CTL_PW |
            WDT_A_CTL_HOLD;


    P4->DIR = ~(BIT0);
    P4->OUT = BIT0;
    P4->REN = BIT0;                         // Enable pull-up resistor (P1.1 output high)
    //P4->DIR = ~(BIT2);
    //P4->OUT = BIT2;
    //P4->REN = BIT2;
    P4->SEL0 = 0;
    P4->SEL1 = 0;
    P4->IFG = 0;                            // Clear all P1 interrupt flags
    P4->IE = BIT0;                          // Enable interrupt for P1.1
    P4->IES = BIT0;                         // Interrupt on high-to-low transition
    //P4->IE = BIT2;                          // Enable interrupt for P1.1
    //P4->IES = BIT2;                         // Interrupt on high-to-low transition

    //GPIO_setAsPeripheralModuleFunctionInputPin(GPIO_PORT_P4, GPIO_PIN0,
      // GPIO_PRIMARY_MODULE_FUNCTION);


    // Enable Port 1 interrupt on the NVIC
    NVIC->ISER[1] = 1 << ((PORT4_IRQn) & 31);

    // Terminate all remaining pins on the device
    P2->DIR |= 0xFF; P2->OUT = 0;
    P3->DIR |= 0xFF; P3->OUT = 0;
    //P4->DIR |= 0xFF; P4->OUT = 0;
    P5->DIR |= 0xFF; P5->OUT = 0;
    P6->DIR |= 0xFF; P6->OUT = 0;
    P7->DIR |= 0xFF; P7->OUT = 0;
    P8->DIR |= 0xFF; P8->OUT = 0;
    P9->DIR |= 0xFF; P9->OUT = 0;
    P10->DIR |= 0xFF; P10->OUT = 0;
    PJ->DIR |= 0xFF; PJ->OUT = 0;

    // Select REFO for ACLK
    CS->KEY = CS_KEY_VAL;
    CS->CTL1 &= ~(CS_CTL1_SELA_MASK);
    CS->CTL1 |= CS_CTL1_SELA__REFOCLK |
            CS_CTL1_SELB;                   // Source REFO to ACLK & BCLK
    CS->CTL2 &= ~(CS_CTL2_LFXTDRIVE_MASK);  // Configure to lowest drive-strength
    CS->KEY = 0;

    // Turn off PSS high-side supervisors
    PSS->KEY = PSS_KEY_KEY_VAL;
    PSS->CTL0 |= PSS_CTL0_SVSMHOFF;
    PSS->KEY = 0;

    // Enable PCM rude mode, which allows to device to enter LPM3 without
    // waiting for peripherals
    PCM->CTL1 = PCM_CTL0_KEY_VAL | PCM_CTL1_FORCE_LPM_ENTRY;

    // Enable all SRAM bank retentions prior to going to LPM3
    SYSCTL->SRAM_BANKRET |= SYSCTL_SRAM_BANKRET_BNK7_RET;

    // Enable global interrupt
    __enable_irq();

    // Setting the sleep deep bit
    SCB->SCR |= (SCB_SCR_SLEEPDEEP_Msk);

    SCB->SCR |= SCB_SCR_SLEEPONEXIT_Msk;    // Do not wake up on exit from ISR

    // Ensures that SLEEPDEEP occurs immediately
    __DSB();

    // Go to LPM3
    __sleep();
}

// Port1 ISR
void PORT4_IRQHandler(void)
{
    volatile uint32_t i;

    // Toggling the output on the LED
   // if(P4->IFG & BIT1)
        //P4->OUT ^= BIT0;
    __low_power_mode_off_on_exit();

    // Delay for switch debounce
   for(i = 0; i < 10000; i++);

    P4->IFG &= ~BIT0;
}

