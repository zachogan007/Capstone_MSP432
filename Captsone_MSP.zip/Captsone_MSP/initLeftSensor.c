/*
 * initLeftPin.c
 *
 *  Created on: Oct 19, 2022
 *      Author: Zac Hogan
 */

#include "msp.h"
#include "TI_Files/PortPins.h"
#include "TI_Files/PushButton.h"






/*!
 * @brief Initialize input for left piezo electric sensor using GPIO library.
 * @param[in] void   Only performs initializing of input pin 4.6. Also initializes Blue LED as output for testing
 * @return NA
 */
void
InitializeLeftSensorPortPin(void)
{


    //Initialize Input Pin P4.6 to read left piezoelectric sensor inputs.
    GPIO_setAsPeripheralModuleFunctionInputPin(GPIO_PORT_P4, GPIO_PIN0,
    GPIO_PRIMARY_MODULE_FUNCTION);


}

