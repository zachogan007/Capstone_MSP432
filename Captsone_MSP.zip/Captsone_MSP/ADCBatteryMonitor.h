/*
 * ADCBatteryMonitor.h
 *
 *  Created on: Nov 6, 2022
 *      Author: Zac Hogan
 */

#ifndef ADCBATTERYMONITOR_H_
#define ADCBATTERYMONITOR_H_




void ADC_BatteryMonitor(void);

float ADC14_IRQHandler(void);





#endif /* ADCBATTERYMONITOR_H_ */
