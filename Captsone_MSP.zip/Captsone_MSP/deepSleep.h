/*
 * deepSleep.h
 *
 *  Created on: Oct 18, 2022
 *      Author: Zac Hogan
 */

#ifndef DEEPSLEEP_H_
#define DEEPSLEEP_H_



void deepSleepMode(void);

void PORT1_IRQHandler(void);



#endif /* DEEPSLEEP_H_ */
