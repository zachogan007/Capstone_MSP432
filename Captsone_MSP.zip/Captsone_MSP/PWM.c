/*
Zachary Hogan (zh6nj)
Module 7: PWM and Motors
04/04/2021
Collaborators:
TA Office Hours
Verbal discussions with Fayzan Rauf
to implement structs for right
and left motors.
*/

#include "TI_Files/driverlib.h"

/* Standard Includes */
#include <stdint.h>

/* Project Includes */
#include "PWM.h"

//struct for the servo timer A0 variables


Timer_A_PWMConfig timeStructServo = {

     TIMER_A_CLOCKSOURCE_SMCLK,
     TIMER_A_CLOCKSOURCE_DIVIDER_2,//   12MHz/10= 1.2MHz => period used is 100 => f = 12,000 Hz so T = 1ms
     0,
     TIMER_A_CAPTURECOMPARE_REGISTER_4,
     TIMER_A_OUTPUTMODE_TOGGLE_SET,
     0
     };

/**
 * Initializes PWM output on P2.6 (right motor) using Timer A0 CCR3 interrupt
 * and on P2.7 (left motor) using the Timer A0 CCR4 interrupt
 * Assumes SMCLK has been initialized to 12 MHz
 * @param period the period of the PWM signal in 83.3 us units
 * @param duty3 the desired duty cycle on P2.6 (TA0 CCR3) as a percent (from 0-100)
 * @param duty4 the desired duty cycle on P2.7 (TA0 CCR4) as a percent (from 0-100)
 * @return none
 */
void PWM_Init(uint16_t period, uint16_t duty){

  //passing in duty cycles for servo
  timeStructServo.dutyCycle = duty;//*period/100;


//passing period called from function into servo
  timeStructServo.timerPeriod = period;

//setting P2.7
 GPIO_setAsPeripheralModuleFunctionOutputPin(GPIO_PORT_P2, GPIO_PIN7, GPIO_PRIMARY_MODULE_FUNCTION);

}



/**
 * Sets the duty cycle of the PWM output on P4.5 (servo)
 * @param duty the desired duty cycle(changes TA0 CCR3)
 * @return none
 */
void PWM_Duty_Servo(uint16_t duty){

    //expressed as a percent
    timeStructServo.dutyCycle = duty;//*(timeStructServo.timerPeriod)/100;

    Timer_A_generatePWM(TIMER_A0_BASE, &timeStructServo);
}

