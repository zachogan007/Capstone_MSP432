/*
 * initLeftSensor.h
 *
 *  Created on: Oct 19, 2022
 *      Author: Zac Hogan
 */

#ifndef INITLEFTSENSOR_H_
#define INITLEFTSENSOR_H_

/*!
 * @brief Initialize input for left piezo electric sensor using GPIO library.
 * @param[in] void   Only performs initializing of input pin 4.6. Also initializes Blue LED as output for testing
 * @return NA
 */
void
InitializeLeftSensorPortPin(void);




#endif /* INITLEFTSENSOR_H_ */
