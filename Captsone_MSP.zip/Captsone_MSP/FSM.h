/*
 * FSM.h
 *
 *  Created on: Oct 22, 2022
 *      Author: Zac Hogan
 */

#ifndef FSM_H_
#define FSM_H_

#include "../Capstone/TI_Files/PortPins.h"
#include "TI_Files/Switch.h"

//These are the Type definitions that dictate FSM state.
typedef enum {

    idle,
    wakeUpAndRecord,
    storeState,
    listenState,
    waitToListen,
    compare,
    unlock,
    lockKnock,
    reset

} FSMState;

//These are the list of the inputs read into the FSM that dictate will serve as the conditions for maintaining FSM.c state.
typedef struct {
    FSMState     CurrentState;
    uint8_t leftSensorInput;
    uint8_t rightSensorInput;
    uint8_t reset;
    uint8_t start;
    uint8_t knockInterrupt;
    uint32_t millisecondRead;
    uint8_t  timerReset;
    SwitchStatus CurrentInputS1;    // Current input of the FSM S1 for starting the program
} FSMType;

/*!
 * @brief InitializeFSM will initialize relevant LED portpins for testing and it will initialize to the Idle State.
 * @param[in] FSMType *FSM, this will carry in an address to the FSM struct that maintains input values and state values.
 * @return void
 */
void InitializeFSM(FSMType *FSM);
/*!
 * @brief NextStateFunction will return the next state of the FSM based on current input conditions.
 * @param[in] FSMType *FSM, this will carry in an address to the FSM struct that maintains input values and state values.
 * @return FSMState, This will update the FSMType struct with the next state to be accessed from main.c.
 */
FSMState NextStateFunction(FSMType *FSM);
/*!
 * @brief This function will access the given case of the FSM state and it will implement controls and outputs per state.
 * @param[in] FSMType *FSM, this will carry in an address to the FSM struct that maintains input values and state values.
 * @return void, this will only implement output controls and will not modify state directly.
 */
void OutputFunction(FSMType *FSM);




#endif /* FSM_H_ */









